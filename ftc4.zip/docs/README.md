Precisamos incluir na descrição que estamos seguindo o principio de deseign de software fast fail. 
"um sistema deve falhar imediatamente e de forma óbvia quando uma condição que impede a continuação é encontrada."


# 🧭 Objetivo do Produto

**“Converter vídeos/áudios em um fichamento didático em Markdown + um quiz interativo de múltipla escolha, tudo em uma interface única, simples e rápida.”**

Valor para o usuário:

* **Economia de tempo** (consumo acelerado de conteúdos longos).
* **Aprendizagem ativa** (quiz para reforçar memorização).
* **Reprodutibilidade** (arquivos `.md` reutilizáveis e versionáveis).

---

# 🧱 Escopo do MVP (foco e limites)

1. **Entrada**: link do YouTube **ou** upload de `mp4/mkv/mp3/wav`.
2. **Extração de áudio**: automática (yt-dlp + ffmpeg).
3. **Transcrição**: WhisperX, com **alinhamento**; **diarização** opcional.
4. **Saída**:

   * **Fichamento Markdown** (resumo, tópicos-chave, takeaways).
   * **Quiz de 5–10 questões** de múltipla escolha (com gabarito e explicações).
5. **Playground Streamlit**: parâmetros básicos (idioma, nível de detalhe, nº de questões).
6. **Deployment**: Streamlit Community Cloud (com Docker local p/ dev).
7. **Sem fine-tuning obrigatório no MVP** (pode entrar como fase 2), o que é coerente com a prova — *ajustar é recomendado, não obrigatório*. 

---

# 🏗️ Arquitetura Lógica (alto nível)

**Frontend (Streamlit)**

* Upload/link → feedback de progresso → exibição do fichamento (`.md`) → quiz interativo → opção de **download do .md**.

**Backend (orquestração)**

1. **Ingestão**

   * Links: `yt_dlp` → download áudio.
   * Vídeo local: `ffmpeg` → extrai trilha de áudio.
   * Áudio local: segue direto.
2. **Transcrição & Pós-processamento**

   * WhisperX → texto + timestamps.
   * Alinhamento: `wav2vec2-large-xlsr-53-portuguese`.
   * Diarização (opcional): `pyannote` → rótulos de falantes.
   * Output JSON consolidado (metadados + segmentos temporais + falantes).
3. **Geração (LLM)**

   * **Fichamento**: transformação de estilo (formal/academic/humor) + seções (Resumo, Insights, Glossário curto, Ações).
   * **Quiz**: múltipla escolha com **feedback explicativo**.
4. **Entrega**

   * Render do `.md` no chat + **download** do arquivo.

**Infra/DevEx**

* **Docker + docker-compose** (ffmpeg e libs nativas).
* **Poetry** para dependências.
* **.env / .env.example** para chaves/tokens/flags.
* **Layout `src/`** padronizado.
* **Deploy** no Streamlit Cloud. 

---

# 🔄 Fluxo de Dados (passo a passo)

1. **Usuário envia** link/arquivo → 2) **Downloader/Extractor** produz `.wav` →
2. **WhisperX** transcreve (texto + timestamps) →
3. **(Opcional) Diarização** associa falas a speakers →
4. **Pós-processamento**: normalização de texto, detecção de tópicos, limpeza →
5. **LLM** gera **Fichamento.md** segundo o estilo escolhido →
6. **LLM** cria **Quiz** balanceado (questões fáceis/médias/difíceis) →
7. **Frontend** exibe, permite feedback e exporta `.md`.

---

# 🧩 Modelos e Decisões Técnicas

* **Transcrição**: *WhisperX* (bom custo/qualidade, rápida; mantém timestamps).
* **Alinhamento**: `wav2vec2-large-xlsr-53-portuguese` melhora precisão temporal.
* **Diarização (opcional)**: `pyannote/speaker-diarization` — útil para aulas/entrevistas.
* **LLM para Fichamento/Quiz**:

  * Inicialmente, **modelo base** (sem fine-tuning) com *prompting* bem projetado.
  * **Fase 2**: ajuste fino (LoRA/PEFT) com dataset de **pares** (transcrição → fichamento/quiz) p/ estilo consistente — exatamente o “ajustar um modelo pré-treinado” pedido na prova, caso deseje elevar a nota. 

---

# 🗂️ Formatos de Dados (descrição conceitual)

* **Transcrição JSON (consolidado)**

  * `metadata`: título, fonte, duração, idioma.
  * `segments[]`: `{start, end, text, speaker?}`.
  * `speakers[]` (opcional): `{id, label, timestamps[]}`.

* **Fichamento Markdown**

  * `# Título`
  * `## Resumo`
  * `## Tópicos-Chave` (bullet points curtos)
  * `## Exemplos/Metáforas`
  * `## Glossário` (3–8 termos)
  * `## Ações/Aplicações Práticas` (2–5 itens)

* **Quiz**

  * `pergunta`, `alternativas[4-5]`, `correta`, `explicacao`.

---

# 🧪 Critérios de Qualidade & Avaliação

* **Transcrição**: taxa de palavras confusas, alinhamento coerente, latência.
* **Fichamento**: cobertura dos tópicos essenciais; **não inventar** conteúdo.
* **Quiz**: variedade de dificuldade, clareza, **justificativas corretas**.
* **Experiência**: tempo total de processamento em vídeo de 5–15 min, UX clara.

---

# 🎛️ Controles e “Guardrails” de IA

* **Anti-alucinação**:

  * Constranger o LLM a **citar trechos** da transcrição ao justificar respostas.
  * Proibir conteúdo não presente nos segmentos.
* **Estilo**: parâmetros no frontend (formal/humorístico/ acadêmico).
* **Comprimento**: limites máximos por seção para evitar verbosidade.

---

# 🧑‍🎨 UX do Streamlit (proposta didática)

* **Sidebar**: upload/link, idioma, diarização on/off, estilo do fichamento, nº de questões.
* **Aba 1 – Fichamento**: render do Markdown + botão **“Baixar .md”**.
* **Aba 2 – Quiz**: múltipla escolha com feedback imediato e **score final**.
* **Aba 3 – Logs/Metadados**: duração do áudio, tempo de processamento, versões dos modelos.

---

# 🔐 Privacidade & Ética

* Informar uso do conteúdo (apenas processamento local/temporário).
* Opção de **não reter** transcrições após a geração.
* Aviso de **direitos autorais** (YouTube): responsabilidade do usuário pela fonte.

---

# 📊 Observabilidade (mínimo viável)

* **Logs estruturados** (ingestão, transcrição, geração LLM, quiz).
* **Métricas**: tempo por etapa, tamanho de entrada/saída, taxa de erro.
* **Tracing simples** (IDs de correlação por requisição).

---

# 💰 Custo & Desempenho (guidelines)

* **Preferir CPU** no MVP (WhisperX pode rodar em CPU para faixas curtas).
* **Batch size e chunking** para áudios longos.
* **Cache** de transcrições (hash do áudio) para evitar retrabalho.
* **Limites**: impor tamanho máximo de arquivo/tempo (ex.: 60–90 min).

---

# 🪜 Roadmap por Fases

1. **MVP**: ingestão + transcrição + fichamento + quiz + Streamlit + Docker.
2. **Qualidade**: diarização, melhores prompts, *post-edit* automático (coerência).
3. **Ajuste fino (opcional)**: LoRA em LLM para estilo “acadêmico didático”. 
4. **Escala**: filas assíncronas (e.g., job queue), cache persistente, storage de artefatos.
5. **Extra**: exportar quiz em formatos (CSV/JSON) e integração com LMS.

---

# ✅ Critérios de Aceitação (checklist da entrega)

* Recebe link/arquivo e retorna **Fichamento.md** + **Quiz** no Streamlit.
* Playground com parâmetros básicos. 
* Logs/mensagens claras das etapas.
* Docker rodando localmente; Poetry gerencia dependências.
* `.env` e `.env.example` documentados.
* Deploy funcional no Streamlit Cloud (link acessível). 

---

# ⚠️ Principais Riscos & Mitigações

* **Áudios longos/pobres** → limite de duração + aviso de qualidade + denoise opcional.
* **Diarização imprecisa** → tratar como “opcional”; não travar fluxo.
* **Alucinação no quiz** → forçar justificativas citando trechos + validação simples.
* **Tempo de processamento** → barra de progresso + estados (“Preparando”, “Transcrevendo”, “Gerando”).

---

# 🧪 Ideias de Extensão (para nota extra)

* **Gabarito comentado com links para trechos (timestamps)**.
* **Mapa temático**: índice por tempo (ex.: 00:03:10 – “Definição X”).
* **Múltiplos estilos de fichamento**: “resumo executivo”, “aula”, “flashcards”.
* **Exportações**: `.md`, `.pdf`, `.csv` do quiz.
* **Avaliação de qualidade automática**: heurísticas simples (cobertura de tópicos, repetição, densidade de palavras-chave).

---

Se curtir essa organização, na próxima mensagem posso **traduzir isso em um plano operacional** (tarefas, estimativas de esforço e riscos por fase) — ainda **sem código**. E quando quiser, seguimos para a **estrutura `src/` + Poetry + Docker** e, por fim, o **deploy**.
